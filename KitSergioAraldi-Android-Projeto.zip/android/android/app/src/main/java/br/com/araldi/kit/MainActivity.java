package br.com.araldi.kit;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
