# Como gerar o APK Android

Este projeto Capacitor está pronto. Para gerar o APK você precisa de:
- Android Studio instalado (https://developer.android.com/studio)
- JDK 17+

## Passo a passo

1. Extraia o zip.
2. Abra o Android Studio → "Open" → selecione a pasta `android/`.
3. Aguarde o Gradle sincronizar.
4. Menu **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. O APK será gerado em `android/app/build/outputs/apk/debug/app-debug.apk`.

Para instalar no celular: ative "Fontes desconhecidas" e transfira o APK.

## Linha de comando (alternativa)
Com Android SDK configurado (`ANDROID_HOME`):
```
cd android && ./gradlew assembleDebug
```
